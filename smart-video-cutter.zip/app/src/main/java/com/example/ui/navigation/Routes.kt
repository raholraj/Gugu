package com.example.ui.navigation

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    
    fun projectDetail(projectId: Int): String = "project_detail/$projectId"
    const val PROJECT_DETAIL_PATTERN = "project_detail/{projectId}"
    
    fun cutting(projectId: Int): String = "cutting/$projectId"
    const val CUTTING_PATTERN = "cutting/{projectId}"
}
