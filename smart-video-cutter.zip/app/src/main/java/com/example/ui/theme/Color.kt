package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic OLED Dark Palette
val DeepOledBlack = Color(0xFF090A0F)
val DarkGrey80 = Color(0xFF13151F)
val CardGrey80 = Color(0xFF1E212E)

// Vibrant CTR/Accent colors
val ElectricOrange = Color(0xFFFF5F1F)
val ElectricBlue = Color(0xFF007FFF)
val CyberCyan = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
