package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.VideoView
import coil.compose.AsyncImage
import com.example.data.database.Clip
import com.example.data.database.Project
import com.example.ui.components.CinemaPlayer
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricOrange
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.VideoCutterViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    projectId: Int,
    viewModel: VideoCutterViewModel,
    onBackClick: () -> Unit,
    onCutClick: () -> Unit
) {
    val context = LocalContext.current
    val projectState = viewModel.getProjectById(projectId).collectAsState(initial = null)
    val project = projectState.value

    val clipsState = viewModel.getClipsForProject(projectId).collectAsState(initial = emptyList())
    val clips = clipsState.value

    var selectedClips by remember { mutableStateOf(setOf<Int>()) }
    var previewingClip by remember { mutableStateOf<Clip?>(null) }
    var isPlayingOriginal by remember { mutableStateOf(false) }

    val formattedTotalSize = remember(clips) {
        val bytes = clips.sumOf { it.fileSize }
        Formatter.formatShortFileSize(context, bytes)
    }

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = ElectricOrange)
        }
        return
    }

    Scaffold(
        topBar = {
            if (selectedClips.isNotEmpty()) {
                // Contextual Action Bar
                TopAppBar(
                    title = { Text("${selectedClips.size} Selected", color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { selectedClips = emptySet() }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear Selection", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            val targetClips = clips.filter { it.id in selectedClips }
                            shareClips(context, targetClips)
                            selectedClips = emptySet()
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Share Selected", tint = Color.White)
                        }
                        IconButton(onClick = {
                            val targetClips = clips.filter { it.id in selectedClips }
                            viewModel.deleteClips(projectId, targetClips)
                            selectedClips = emptySet()
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Selected", tint = Color.Red)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )
            } else {
                TopAppBar(
                    title = {
                        Text(
                            text = project.name,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Go Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = onCutClick) {
                            Icon(Icons.Default.ContentCut, contentDescription = "Cut Video", tint = ElectricOrange)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Video Player
            CinemaPlayer(
                videoPath = project.videoPath,
                isPlaying = isPlayingOriginal,
                modifier = Modifier.fillMaxWidth()
            )

            // Playback controls row for Original
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { isPlayingOriginal = !isPlayingOriginal },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPlayingOriginal) Color.DarkGray else ElectricOrange
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.height(40.dp)
                ) {
                    Icon(
                        imageVector = if (isPlayingOriginal) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlayingOriginal) "Pause Original" else "Play Original",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPlayingOriginal) "Pause Reference" else "Play Reference",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Stats Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Clips Extracted", fontSize = 11.sp, color = TextSecondary)
                        Text("${clips.size} clips", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                    }
                    Divider(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp),
                        color = Color.Gray.copy(alpha = 0.5f)
                    )
                    Column {
                        Text("Storage Occupied", fontSize = 11.sp, color = TextSecondary)
                        Text(formattedTotalSize, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ElectricOrange)
                    }
                }
            }

            // Clips List Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Generated Clips",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.White
                )
                
                if (clips.isNotEmpty() && selectedClips.isEmpty()) {
                    TextButton(onClick = { selectedClips = clips.map { it.id }.toSet() }) {
                        Text("Select All", color = ElectricBlue)
                    }
                }
            }

            if (clips.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCut,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(60.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Clips Cut Yet",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tap the scissor icon on the top right or the button below to start cutting smart segments.",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onCutClick,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricOrange),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Text("Open Cutting Studio", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(clips, key = { it.id }) { clip ->
                        ClipRowItem(
                            clip = clip,
                            isSelected = clip.id in selectedClips,
                            selectionModeActive = selectedClips.isNotEmpty(),
                            onToggleSelection = {
                                selectedClips = if (clip.id in selectedClips) {
                                    selectedClips - clip.id
                                } else {
                                    selectedClips + clip.id
                                }
                            },
                            onPlayClick = { previewingClip = clip },
                            onShareClick = { shareVideoFile(context, clip.videoPath) },
                            onDeleteClick = { viewModel.deleteClip(clip) }
                        )
                    }
                }
            }
        }

        // Custom Overlay dialog for in-app clip playing (very premium dark overlay!)
        previewingClip?.let { clip ->
            AlertDialog(
                onDismissRequest = { previewingClip = null },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = clip.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { previewingClip = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close player")
                        }
                    }
                },
                text = {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                VideoView(ctx).apply {
                                    setVideoPath(clip.videoPath)
                                    setOnPreparedListener { mp ->
                                        mp.isLooping = true
                                        start()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { shareVideoFile(context, clip.videoPath) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricOrange)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Clip")
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ClipRowItem(
    clip: Clip,
    isSelected: Boolean,
    selectionModeActive: Boolean,
    onToggleSelection: () -> Unit,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    val formattedDuration = remember(clip.durationMs) {
        formatMsToTime(clip.durationMs)
    }

    val formattedRange = remember(clip.startMs, clip.endMs) {
        "${formatMsToTime(clip.startMs)} - ${formatMsToTime(clip.endMs)}"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = {
                    if (selectionModeActive) {
                        onToggleSelection()
                    } else {
                        onPlayClick()
                    }
                },
                onLongClick = {
                    if (!selectionModeActive) {
                        onToggleSelection()
                    }
                }
            )
            .testTag("clip_card_${clip.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Selector box or play button
                if (selectionModeActive) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelection() },
                        colors = CheckboxDefaults.colors(checkedColor = ElectricOrange)
                    )
                } else {
                    IconButton(
                        onClick = onPlayClick,
                        modifier = Modifier
                            .background(ElectricOrange.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                            .size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play Clip",
                            tint = ElectricOrange,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = clip.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Range: $formattedRange • Size: ${Formatter.formatShortFileSize(context, clip.fileSize)}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Text(
                    text = formattedDuration,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = ElectricOrange
                )

                // Dropdown details toggle
                if (clip.aiReasoning != null) {
                    IconButton(onClick = { isExpanded = !isExpanded }) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Show AI Info",
                            tint = Color.White
                        )
                    }
                }
            }

            // Expanded reasoning details
            AnimatedVisibility(
                visible = isExpanded && clip.aiReasoning != null,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = ElectricBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "AI Suggested Choice",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = ElectricBlue
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = clip.aiReasoning ?: "",
                        fontSize = 12.sp,
                        color = Color.LightGray,
                        lineHeight = 16.sp
                    )
                }
            }

            // Secondary action options row (only if not in selection mode)
            if (!selectionModeActive) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(onClick = onShareClick) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDeleteClick) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

// Utility to format milliseconds into 00:00 structure
fun formatMsToTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
}

fun shareVideoFile(context: Context, filePath: String) {
    try {
        val file = File(filePath)
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Video Clip"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

fun shareClips(context: Context, clips: List<Clip>) {
    try {
        val uris = ArrayList<Uri>()
        clips.forEach { clip ->
            val file = File(clip.videoPath)
            if (file.exists()) {
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                uris.add(uri)
            }
        }
        if (uris.isEmpty()) return

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "video/mp4"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Share Video Clips"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
