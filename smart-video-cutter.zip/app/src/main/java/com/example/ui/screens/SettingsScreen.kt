package com.example.ui.screens

import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricOrange
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.VideoCutterViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: VideoCutterViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val apiKey by viewModel.groqApiKey.collectAsState()
    val projects by viewModel.projects.collectAsState()

    var tempApiKey by remember { mutableStateOf(apiKey) }
    var isEditingKey by remember { mutableStateOf(false) }

    val totalGlobalStorage = remember(projects) {
        projects.sumOf { it.totalStorageUsed }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Storage", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Groq API Section
            item {
                Text(
                    text = "AI Services",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricOrange
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Key, null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Groq API Key", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Used for Whisper Audio Transcription and Llama 3 moment suggestion. Keys are encrypted and saved locally in secure storage.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        if (isEditingKey) {
                            TextField(
                                value = tempApiKey,
                                onValueChange = { tempApiKey = it },
                                placeholder = { Text("gsk_...") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("api_key_input"),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Black.copy(alpha = 0.2f),
                                    unfocusedContainerColor = Color.Black.copy(alpha = 0.2f)
                                ),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = {
                                    tempApiKey = apiKey
                                    isEditingKey = false
                                }) {
                                    Text("Cancel")
                                }
                                Button(
                                    onClick = {
                                        viewModel.updateApiKey(tempApiKey)
                                        isEditingKey = false
                                        Toast.makeText(context, "API Key saved securely!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricOrange)
                                ) {
                                    Text("Save Key")
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (apiKey.isBlank()) "No Key Configured" else "••••••••••••••••" + apiKey.takeLast(4),
                                    color = if (apiKey.isBlank()) Color.Gray else Color.White,
                                    fontSize = 14.sp
                                )
                                TextButton(onClick = { isEditingKey = true }) {
                                    Text(if (apiKey.isBlank()) "Configure" else "Modify", color = ElectricBlue)
                                }
                            }
                        }
                    }
                }
            }

            // Storage Summary Section
            item {
                Text(
                    text = "System Disk Storage",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricOrange
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, null, tint = ElectricOrange, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Disk Utilization", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Accumulated size of all generated MP4 cuts across all movie projects on your local device.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text("Global Cache size", fontSize = 11.sp, color = TextSecondary)
                                Text(
                                    text = Formatter.formatShortFileSize(context, totalGlobalStorage),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ElectricOrange
                                )
                            }

                            Button(
                                onClick = {
                                    // Deletes all clips files from projects
                                    projects.forEach { proj ->
                                        viewModel.deleteProject(proj)
                                    }
                                    Toast.makeText(context, "All movie projects and clips cleared!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f))
                            ) {
                                Icon(Icons.Default.DeleteForever, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear All Data")
                            }
                        }
                    }
                }
            }

            // Storage breakdown list title
            item {
                Text(
                    text = "Project Footprint Breakdown",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            // Breakdown Items
            if (projects.isEmpty()) {
                item {
                    Text(
                        text = "No active movie projects on disk.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            } else {
                items(projects, key = { it.id }) { project ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = project.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Path: " + File(project.videoPath).parent ?: "",
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = Formatter.formatShortFileSize(context, project.totalStorageUsed),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = ElectricOrange
                            )
                        }
                    }
                }
            }
        }
    }
}
