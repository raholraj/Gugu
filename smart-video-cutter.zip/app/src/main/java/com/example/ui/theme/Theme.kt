package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElectricOrange,
    secondary = ElectricBlue,
    tertiary = CyberCyan,
    background = DeepOledBlack,
    surface = DarkGrey80,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = CardGrey80,
    onSurfaceVariant = TextSecondary
  )

private val LightColorScheme = DarkColorScheme // Forced Dark Theme by Default for premium cinematic editing

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme for video application
  dynamicColor: Boolean = false, // Disable dynamic light schemes to keep cohesive cinematic branding
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
