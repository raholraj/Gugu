package com.example.ui.components

import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.ElectricOrange
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun CinemaPlayer(
    videoPath: String,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = false,
    onProgressUpdate: (Long) -> Unit = {},
    seekToMs: Long? = null,
    onDurationLoaded: (Long) -> Unit = {}
) {
    var videoViewInstance by remember { mutableStateOf<VideoView?>(null) }

    // Synchronize play/pause state from Compose
    LaunchedEffect(isPlaying) {
        videoViewInstance?.let {
            if (isPlaying) {
                it.start()
            } else {
                it.pause()
            }
        }
    }

    // Synchronize seeking from timeline scrubber
    LaunchedEffect(seekToMs) {
        seekToMs?.let { ms ->
            videoViewInstance?.let {
                it.seekTo(ms.toInt())
            }
        }
    }

    // Track playback progress
    LaunchedEffect(videoViewInstance, isPlaying) {
        while (isPlaying) {
            videoViewInstance?.let {
                onProgressUpdate(it.currentPosition.toLong())
            }
            delay(100)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            factory = { context ->
                VideoView(context).apply {
                    setVideoPath(videoPath)
                    setOnPreparedListener { mp ->
                        mp.isLooping = true
                        onDurationLoaded(mp.duration.toLong())
                        if (isPlaying) {
                            start()
                        }
                    }
                }
            },
            update = { view ->
                videoViewInstance = view
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}
