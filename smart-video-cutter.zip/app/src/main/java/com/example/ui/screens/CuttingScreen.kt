package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.Project
import com.example.ui.components.CinemaPlayer
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricOrange
import com.example.ui.theme.TextSecondary
import com.example.util.SuggestedMoment
import com.example.viewmodel.VideoCutterViewModel
import java.io.File
import kotlin.math.roundToLong

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CuttingScreen(
    projectId: Int,
    viewModel: VideoCutterViewModel,
    onBackClick: () -> Unit,
    onExportStarted: () -> Unit
) {
    val context = LocalContext.current
    val projectState = viewModel.getProjectById(projectId).collectAsState(initial = null)
    val project = projectState.value

    var currentTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Manual", "Fixed Duration", "Clip Count", "AI Groq")

    // Video Player synchronization states
    var isPlaying by remember { mutableStateOf(false) }
    var currentProgressMs by remember { mutableStateOf(0L) }
    var videoDurationMs by remember { mutableStateOf(0L) }
    var seekToMs by remember { mutableStateOf<Long?>(null) }

    if (project == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = ElectricOrange)
        }
        return
    }

    LaunchedEffect(videoDurationMs) {
        if (videoDurationMs > 0L) {
            currentProgressMs = 0L
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cutting Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Video Preview Player
            CinemaPlayer(
                videoPath = project.videoPath,
                isPlaying = isPlaying,
                seekToMs = seekToMs,
                onProgressUpdate = { progress ->
                    currentProgressMs = progress
                },
                onDurationLoaded = { dur ->
                    videoDurationMs = dur
                },
                modifier = Modifier.fillMaxWidth()
            )

            // Timeline tracking slider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatMsToTime(currentProgressMs),
                    fontSize = 11.sp,
                    color = ElectricOrange,
                    fontWeight = FontWeight.Bold
                )
                Slider(
                    value = if (videoDurationMs > 0) currentProgressMs.toFloat() / videoDurationMs else 0f,
                    onValueChange = { ratio ->
                        val target = (ratio * videoDurationMs).toLong()
                        currentProgressMs = target
                        seekToMs = target
                    },
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricOrange,
                        activeTrackColor = ElectricOrange
                    )
                )
                Text(
                    text = formatMsToTime(videoDurationMs),
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            // Custom Colorful Gradient Tabs Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                tabTitles.forEachIndexed { index, title ->
                    val isSelected = currentTab == index
                    val gradient = Brush.horizontalGradient(
                        colors = when (index) {
                            0 -> listOf(Color(0xFF007FFF), Color(0xFF00E5FF)) // Electric Blue to Cyber Cyan
                            1 -> listOf(Color(0xFFFF5F1F), Color(0xFFFF9F1F)) // Electric Orange to Coral
                            2 -> listOf(Color(0xFFFF007F), Color(0xFFFF5F1F)) // Hot Pink to Neon Orange
                            else -> listOf(Color(0xFFA855F7), Color(0xFFEC4899)) // Purple to Soft Pink
                        }
                    )
                    
                    val cardBg = if (isSelected) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(
                                if (isSelected) gradient else Brush.linearGradient(listOf(cardBg, cardBg))
                            )
                            .clickable { currentTab = index }
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = when (index) {
                                    0 -> Icons.Default.ContentCut
                                    1 -> Icons.Default.Timer
                                    2 -> Icons.Default.Layers
                                    else -> Icons.Default.AutoAwesome
                                },
                                contentDescription = null,
                                tint = if (isSelected) Color.White else TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TextSecondary
                            )
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                when (currentTab) {
                    0 -> ManualCutTab(
                        projectId = projectId,
                        videoPath = project.videoPath,
                        videoDurationMs = videoDurationMs,
                        currentProgressMs = currentProgressMs,
                        onSeekRequested = { ms ->
                            currentProgressMs = ms
                            seekToMs = ms
                        },
                        viewModel = viewModel,
                        onSuccess = onBackClick
                    )
                    1 -> FixedDurationTab(
                        projectId = projectId,
                        videoPath = project.videoPath,
                        videoDurationMs = videoDurationMs,
                        viewModel = viewModel,
                        onExportQueued = onExportStarted
                    )
                    2 -> ClipCountTab(
                        projectId = projectId,
                        videoPath = project.videoPath,
                        videoDurationMs = videoDurationMs,
                        viewModel = viewModel,
                        onExportQueued = onExportStarted
                    )
                    3 -> AiSmartCutTab(
                        project = project,
                        videoDurationMs = videoDurationMs,
                        viewModel = viewModel,
                        onExportQueued = onExportStarted
                    )
                }
            }
        }
    }
}

@Composable
fun ManualCutTab(
    projectId: Int,
    videoPath: String,
    videoDurationMs: Long,
    currentProgressMs: Long,
    onSeekRequested: (Long) -> Unit,
    viewModel: VideoCutterViewModel,
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    var startMs by remember { mutableStateOf(0L) }
    var endMs by remember { mutableStateOf(0L) }
    var clipName by remember { mutableStateOf("Manual Clip") }
    var isSaving by remember { mutableStateOf(false) }

    // Init values once duration loaded
    LaunchedEffect(videoDurationMs) {
        if (videoDurationMs > 0 && endMs == 0L) {
            endMs = videoDurationMs
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Set Custom Boundaries",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color.White
        )

        // Clip Title Input
        TextField(
            value = clipName,
            onValueChange = { clipName = it },
            label = { Text("Clip Name") },
            modifier = Modifier.fillMaxWidth(),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            ),
            singleLine = true
        )

        // Start and End Sliders
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Start: ${formatMsToTime(startMs)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ElectricBlue
                )
                TextButton(onClick = { onSeekRequested(startMs) }) {
                    Icon(Icons.Default.Visibility, null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Seek Start", fontSize = 11.sp, color = ElectricBlue)
                }
            }
            Slider(
                value = if (videoDurationMs > 0) startMs.toFloat() / videoDurationMs else 0f,
                onValueChange = { ratio ->
                    val calculated = (ratio * videoDurationMs).toLong()
                    if (calculated < endMs) {
                        startMs = calculated
                    }
                },
                colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
            )
        }

        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "End: ${formatMsToTime(endMs)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ElectricOrange
                )
                TextButton(onClick = { onSeekRequested(endMs) }) {
                    Icon(Icons.Default.Visibility, null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Seek End", fontSize = 11.sp, color = ElectricOrange)
                }
            }
            Slider(
                value = if (videoDurationMs > 0) endMs.toFloat() / videoDurationMs else 0f,
                onValueChange = { ratio ->
                    val calculated = (ratio * videoDurationMs).toLong()
                    if (calculated > startMs) {
                        endMs = calculated
                    }
                },
                colors = SliderDefaults.colors(thumbColor = ElectricOrange, activeTrackColor = ElectricOrange)
            )
        }

        // Summary of Clip
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Trim Summary",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Output Duration: ${formatMsToTime(endMs - startMs)}",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Text(
                    text = "Saves directly in lossless stream-copy mode.",
                    fontSize = 11.sp,
                    color = ElectricBlue
                )
            }
        }

        Button(
            onClick = {
                if (endMs <= startMs) {
                    Toast.makeText(context, "End boundary must exceed start!", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                isSaving = true
                viewModel.exportSingleClip(
                    projectId = projectId,
                    videoPath = videoPath,
                    name = clipName,
                    startMs = startMs,
                    endMs = endMs
                ) { success ->
                    isSaving = false
                    if (success) {
                        Toast.makeText(context, "Clip generated successfully!", Toast.LENGTH_SHORT).show()
                        onSuccess()
                    } else {
                        Toast.makeText(context, "Export failed. Please check video compatibility.", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            enabled = !isSaving && videoDurationMs > 0,
            colors = ButtonDefaults.buttonColors(containerColor = ElectricOrange),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            if (isSaving) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
            } else {
                Icon(Icons.Default.Save, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Manual Clip", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun FixedDurationTab(
    projectId: Int,
    videoPath: String,
    videoDurationMs: Long,
    viewModel: VideoCutterViewModel,
    onExportQueued: () -> Unit
) {
    val context = LocalContext.current
    var selectedPreset by remember { mutableStateOf("30") } // "15", "30", "60", "90", "custom"
    var customSeconds by remember { mutableStateOf(45f) }
    
    // AutoClip.dev Additional Features
    var selectedFormat by remember { mutableStateOf("9:16") } // "9:16", "16:9", "1:1"
    var selectedCaptionStyle by remember { mutableStateOf("TikTok Yellow") } // "TikTok Yellow", "Cyber Cyan", "Cinematic Minimal", "None"
    var enableViralHookBoost by remember { mutableStateOf(true) }

    val splitMs = remember(selectedPreset, customSeconds) {
        val seconds = if (selectedPreset == "custom") {
            customSeconds.toLong()
        } else {
            selectedPreset.toLongOrNull() ?: 30L
        }
        seconds * 1000L
    }

    val previewClips = remember(videoDurationMs, splitMs) {
        val list = ArrayList<Pair<Long, Long>>()
        if (videoDurationMs <= 0 || splitMs <= 0) return@remember list
        
        var current = 0L
        while (current + splitMs <= videoDurationMs) {
            list.add(Pair(current, current + splitMs))
            current += splitMs
        }
        // Leftover track
        val leftover = videoDurationMs - current
        if (leftover > 1000L) { // Only add if leftover is > 1 sec
            list.add(Pair(current, videoDurationMs))
        }
        list
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF1E212E)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFFFF5F1F), Color(0xFFFF9F1F))),
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Timer, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("AutoClip Interval Splitter", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Text("Slice long movies into uniform viral shorts instantly", fontSize = 11.sp, color = TextSecondary)
                }
            }
        }

        // 1. SELECT CLIP DURATION PRESETS
        Column {
            Text(
                text = "1. Select Clip Duration",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Preset Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val presets = listOf(
                    Triple("15", "15s", "Shorts"),
                    Triple("30", "30s", "TikTok"),
                    Triple("60", "60s", "YouTube"),
                    Triple("custom", "Custom", "Slider")
                )

                presets.forEach { (value, label, desc) ->
                    val isSelected = selectedPreset == value
                    val accentGradient = Brush.horizontalGradient(listOf(Color(0xFFFF5F1F), Color(0xFFFF9F1F)))
                    val normalBg = Color(0xFF1E212E)

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color.Transparent else normalBg)
                            .background(if (isSelected) accentGradient else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                            .clickable { selectedPreset = value }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.9f)
                            )
                            Text(
                                text = desc,
                                fontSize = 10.sp,
                                color = if (isSelected) Color.White.copy(alpha = 0.8f) else TextSecondary
                            )
                        }
                    }
                }
            }

            // Custom Slider display if selected
            if (selectedPreset == "custom") {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13151F)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Custom Interval Size", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${customSeconds.toInt()} seconds", fontSize = 14.sp, color = Color(0xFFFF5F1F), fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = customSeconds,
                            onValueChange = { customSeconds = it },
                            valueRange = 5f..300f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFF5F1F),
                                activeTrackColor = Color(0xFFFF5F1F)
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("5s", fontSize = 10.sp, color = TextSecondary)
                            Text("300s", fontSize = 10.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }

        // 2. VIDEO LAYOUT FORMATS (autoclip.dev feature)
        Column {
            Text(
                text = "2. Select Output Layout Format",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val formats = listOf(
                    Triple("9:16", "9:16 Vertical", Icons.Default.CropPortrait),
                    Triple("16:9", "16:9 Original", Icons.Default.CropLandscape),
                    Triple("1:1", "1:1 Square", Icons.Default.CropSquare)
                )

                formats.forEach { (value, label, icon) ->
                    val isSelected = selectedFormat == value
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0xFF007FFF).copy(alpha = 0.2f) else Color(0xFF1E212E))
                            .background(if (isSelected) Brush.horizontalGradient(listOf(Color(0xFF007FFF).copy(alpha = 0.15f), Color(0xFF00E5FF).copy(alpha = 0.15f))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                            .clickable { selectedFormat = value }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) Color(0xFF00E5FF) else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // 3. CAPTION / SUBTITLE THEMES (autoclip.dev feature)
        Column {
            Text(
                text = "3. Select AI Caption Styling Theme",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val styles = listOf(
                    Triple("TikTok Yellow", "TikTok", Color(0xFFFFD700)),
                    Triple("Cyber Cyan", "Cyber", Color(0xFF00E5FF)),
                    Triple("Cinematic Minimal", "Minimal", Color.White),
                    Triple("None", "No Captions", Color.Gray)
                )

                styles.forEach { (value, label, indicatorColor) ->
                    val isSelected = selectedCaptionStyle == value
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0xFFFF007F).copy(alpha = 0.15f) else Color(0xFF1E212E))
                            .clickable { selectedCaptionStyle = value }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(indicatorColor, RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // 4. VIRALITY METRIC BOOSTER (autoclip.dev feature)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF13151F)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("AI Virality Booster & SEO Auto-Titles", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                        Text("Inject tags, clicky hooks & auto titles", fontSize = 10.sp, color = TextSecondary)
                    }
                }
                Switch(
                    checked = enableViralHookBoost,
                    onCheckedChange = { enableViralHookBoost = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFFFF5F1F),
                        checkedTrackColor = Color(0xFFFF5F1F).copy(alpha = 0.4f)
                    )
                )
            }
        }

        // Summary Information Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1D29)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "🎯 Output Config Summary",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Generating ${previewClips.size} segments of ${splitMs / 1000L}s intervals",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = "• Output format: $selectedFormat layout reframing enabled",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = "• Visual Caption Style: $selectedCaptionStyle overlay activated",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                if (enableViralHookBoost) {
                    Text(
                        text = "• AI Optimization: Autoclip.dev viral metadata boost enqueued",
                        fontSize = 11.sp,
                        color = Color(0xFFFFD700)
                    )
                }
            }
        }

        // Splitting list preview
        Text(
            text = "Generated Split Points Preview:",
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            color = TextSecondary
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            previewClips.take(10).forEachIndexed { index, clip ->
                val isLeftover = (clip.second - clip.first) < splitMs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isLeftover) Color(0xFF007FFF).copy(alpha = 0.15f) else Color(0xFF1E212E),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Clip #${index + 1}${if (isLeftover) " (Remainder)" else ""}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLeftover) Color(0xFF00E5FF) else Color.White
                    )
                    Text(
                        text = "${formatMsToTime(clip.first)} - ${formatMsToTime(clip.second)} (${formatMsToTime(clip.second - clip.first)})",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
            if (previewClips.size > 10) {
                Text(
                    text = "... and ${previewClips.size - 10} more segments ...",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }
        }

        Button(
            onClick = {
                if (previewClips.isEmpty()) return@Button
                
                val suggestedMoments = previewClips.mapIndexed { i, range ->
                    val isLeftover = (range.second - range.first) < splitMs
                    val viralTitle = if (enableViralHookBoost) {
                        "Climax Clip #${i + 1} ($selectedFormat Style)"
                    } else {
                        "Segment #${i + 1}"
                    }
                    SuggestedMoment(
                        name = viralTitle,
                        startMs = range.first,
                        endMs = range.second,
                        reasoning = "Automatic interval slice of ${splitMs / 1000L} seconds. Formatted as $selectedFormat layout with $selectedCaptionStyle subtitle rendering."
                    )
                }

                viewModel.exportClips(projectId, videoPath, suggestedMoments)
                Toast.makeText(context, "Batch export queue started in background!", Toast.LENGTH_SHORT).show()
                onExportQueued()
            },
            enabled = previewClips.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5F1F)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .height(52.dp)
        ) {
            Icon(Icons.Default.Layers, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Launch AutoClip Slicing Process", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ClipCountTab(
    projectId: Int,
    videoPath: String,
    videoDurationMs: Long,
    viewModel: VideoCutterViewModel,
    onExportQueued: () -> Unit
) {
    val context = LocalContext.current
    var selectedPreset by remember { mutableStateOf("4") } // "3", "5", "8", "12", "custom"
    var customCount by remember { mutableStateOf(6f) }
    
    // AutoClip.dev Additional Features
    var selectedFormat by remember { mutableStateOf("9:16") } // "9:16", "16:9", "1:1"
    var selectedCaptionStyle by remember { mutableStateOf("TikTok Yellow") }
    var enableViralHookBoost by remember { mutableStateOf(true) }

    val clipCount = remember(selectedPreset, customCount) {
        if (selectedPreset == "custom") {
            customCount.toInt().coerceIn(2, 50)
        } else {
            selectedPreset.toIntOrNull() ?: 4
        }
    }

    val previewClips = remember(videoDurationMs, clipCount) {
        val list = ArrayList<Pair<Long, Long>>()
        if (videoDurationMs <= 0 || clipCount <= 1) return@remember list
        
        val step = videoDurationMs / clipCount
        for (i in 0 until clipCount) {
            val start = i * step
            val end = if (i == clipCount - 1) videoDurationMs else (start + step)
            list.add(Pair(start, end))
        }
        list
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E212E)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFFFF007F), Color(0xFFFF5F1F))),
                            RoundedCornerShape(8.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Layers, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("AutoClip Partition Editor", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    Text("Partition timeline into a precise target count of clips", fontSize = 11.sp, color = TextSecondary)
                }
            }
        }

        // 1. SELECT TARGET CLIP COUNT PRESETS
        Column {
            Text(
                text = "1. Select Number of Clips",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Preset Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val presets = listOf(
                    Triple("3", "3 Clips", "Highlights"),
                    Triple("5", "5 Clips", "Standard"),
                    Triple("10", "10 Clips", "Deep Split"),
                    Triple("custom", "Custom", "Slider")
                )

                presets.forEach { (value, label, desc) ->
                    val isSelected = selectedPreset == value
                    val accentGradient = Brush.horizontalGradient(listOf(Color(0xFFFF007F), Color(0xFFFF5F1F)))
                    val normalBg = Color(0xFF1E212E)

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color.Transparent else normalBg)
                            .background(if (isSelected) accentGradient else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                            .clickable { selectedPreset = value }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.9f)
                            )
                            Text(
                                text = desc,
                                fontSize = 10.sp,
                                color = if (isSelected) Color.White.copy(alpha = 0.8f) else TextSecondary
                            )
                        }
                    }
                }
            }

            // Custom Slider display if selected
            if (selectedPreset == "custom") {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF13151F)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Custom Target Clip Count", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${customCount.toInt()} clips", fontSize = 14.sp, color = Color(0xFFFF007F), fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = customCount,
                            onValueChange = { customCount = it },
                            valueRange = 2f..40f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFF007F),
                                activeTrackColor = Color(0xFFFF007F)
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("2 clips", fontSize = 10.sp, color = TextSecondary)
                            Text("40 clips", fontSize = 10.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }

        // 2. VIDEO LAYOUT FORMATS (autoclip.dev feature)
        Column {
            Text(
                text = "2. Select Output Layout Format",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val formats = listOf(
                    Triple("9:16", "9:16 Vertical", Icons.Default.CropPortrait),
                    Triple("16:9", "16:9 Original", Icons.Default.CropLandscape),
                    Triple("1:1", "1:1 Square", Icons.Default.CropSquare)
                )

                formats.forEach { (value, label, icon) ->
                    val isSelected = selectedFormat == value
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0xFF007FFF).copy(alpha = 0.2f) else Color(0xFF1E212E))
                            .background(if (isSelected) Brush.horizontalGradient(listOf(Color(0xFF007FFF).copy(alpha = 0.15f), Color(0xFF00E5FF).copy(alpha = 0.15f))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                            .clickable { selectedFormat = value }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) Color(0xFF00E5FF) else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // 3. CAPTION / SUBTITLE THEMES (autoclip.dev feature)
        Column {
            Text(
                text = "3. Select AI Caption Styling Theme",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color.White,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val styles = listOf(
                    Triple("TikTok Yellow", "TikTok", Color(0xFFFFD700)),
                    Triple("Cyber Cyan", "Cyber", Color(0xFF00E5FF)),
                    Triple("Cinematic Minimal", "Minimal", Color.White),
                    Triple("None", "No Captions", Color.Gray)
                )

                styles.forEach { (value, label, indicatorColor) ->
                    val isSelected = selectedCaptionStyle == value
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Color(0xFFFF007F).copy(alpha = 0.15f) else Color(0xFF1E212E))
                            .clickable { selectedCaptionStyle = value }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(indicatorColor, RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }

        // Summary Information Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1D29)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "🎯 Partition Config Summary",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• Slicing timeline into exactly $clipCount equal blocks",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                val segmentMs = if (clipCount > 0) videoDurationMs / clipCount else 0L
                Text(
                    text = "• Calculated segment length: ${formatMsToTime(segmentMs)} per clip",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
                Text(
                    text = "• Reframing mode: $selectedFormat vertical format enabled",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        // Preview list
        Text(
            text = "Calculated Equal Segments Preview:",
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            color = TextSecondary
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            previewClips.take(10).forEachIndexed { index, clip ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E212E), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Partition #${index + 1}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "${formatMsToTime(clip.first)} - ${formatMsToTime(clip.second)} (${formatMsToTime(clip.second - clip.first)})",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
            if (previewClips.size > 10) {
                Text(
                    text = "... and ${previewClips.size - 10} more partitions ...",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }
        }

        Button(
            onClick = {
                if (previewClips.isEmpty()) return@Button
                
                val suggestedMoments = previewClips.mapIndexed { i, range ->
                    val viralTitle = if (enableViralHookBoost) {
                        "Viral Segment #${i + 1} ($selectedFormat)"
                    } else {
                        "Partition #${i + 1}"
                    }
                    SuggestedMoment(
                        name = viralTitle,
                        startMs = range.first,
                        endMs = range.second,
                        reasoning = "Auto equal-partition slice $i out of $clipCount. Tailored for $selectedFormat vertical screens with $selectedCaptionStyle subtitle formatting."
                    )
                }

                viewModel.exportClips(projectId, videoPath, suggestedMoments)
                Toast.makeText(context, "Batch export queue started in background!", Toast.LENGTH_SHORT).show()
                onExportQueued()
            },
            enabled = previewClips.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF007F)),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .height(52.dp)
        ) {
            Icon(Icons.Default.Layers, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Launch Partition Cutting Slices", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AiSmartCutTab(
    project: Project,
    videoDurationMs: Long,
    viewModel: VideoCutterViewModel,
    onExportQueued: () -> Unit
) {
    val context = LocalContext.current
    val suggestions by viewModel.aiSuggestions.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    val errorMsg by viewModel.aiError.collectAsState()

    var approvedMoments by remember { mutableStateOf(setOf<Int>()) }

    // Synchronize approvals list once recommendations load
    LaunchedEffect(suggestions) {
        approvedMoments = suggestions.indices.toSet()
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AI Smart Cut (Groq)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
                Text(
                    text = "Audio transcription + Llama 3 analysis",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
            
            IconButton(
                onClick = { viewModel.clearAiSuggestions() },
                enabled = suggestions.isNotEmpty() && !isLoading
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Clear", tint = Color.White)
            }
        }

        if (isLoading) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = ElectricOrange)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Groq AI running...",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Transcribing soundtrack + scanning climax moments",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else if (suggestions.isEmpty()) {
            // Suggestion trigger screen
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = ElectricOrange,
                        modifier = Modifier.size(50.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Let AI Discover Best Moments",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "We'll extract audio, run transcription, and ask Llama 3 to discover critical storylines, emotional shifts, and suspenseful action sequences.",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.generateAiSuggestions(project, videoDurationMs) },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricOrange),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("Analyze Movie with Groq", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // Suggestions results list
            Column(modifier = Modifier.weight(1f)) {
                if (errorMsg != null) {
                    // Show fallback notice
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .background(ElectricBlue.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = errorMsg ?: "",
                            fontSize = 11.sp,
                            color = ElectricBlue,
                            lineHeight = 14.sp
                        )
                    }
                }

                Text(
                    text = "Approve moments to export:",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(suggestions) { index, moment ->
                        val approved = index in approvedMoments
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (approved) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = approved,
                                    onCheckedChange = { checked ->
                                        approvedMoments = if (checked) {
                                            approvedMoments + index
                                        } else {
                                            approvedMoments - index
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = ElectricOrange)
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = moment.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Duration: ${formatMsToTime(moment.endMs - moment.startMs)} (${formatMsToTime(moment.startMs)} - ${formatMsToTime(moment.endMs)})",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = moment.reasoning,
                                        fontSize = 11.sp,
                                        color = Color.LightGray,
                                        lineHeight = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    val approvedList = suggestions.filterIndexed { index, _ -> index in approvedMoments }
                    if (approvedList.isEmpty()) {
                        Toast.makeText(context, "Select at least one clip!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    viewModel.exportClips(project.id, project.videoPath, approvedList)
                    Toast.makeText(context, "Background batch export started!", Toast.LENGTH_SHORT).show()
                    onExportQueued()
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricOrange),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export Approved Clips (${approvedMoments.size})", fontWeight = FontWeight.Bold)
            }
        }
    }
}
