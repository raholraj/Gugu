package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.navigation.Routes
import com.example.ui.screens.CuttingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProjectDetailScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.VideoCutterViewModel
import com.example.viewmodel.VideoCutterViewModelFactory

class MainActivity : ComponentActivity() {
    
    private val viewModel: VideoCutterViewModel by viewModels {
        VideoCutterViewModelFactory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()
                
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = Routes.HOME
                    ) {
                        // Home Dashboard Screen
                        composable(Routes.HOME) {
                            HomeScreen(
                                viewModel = viewModel,
                                onProjectClick = { projectId ->
                                    navController.navigate(Routes.projectDetail(projectId))
                                },
                                onSettingsClick = {
                                    navController.navigate(Routes.SETTINGS)
                                }
                            )
                        }

                        // Project Details Screen
                        composable(
                            route = Routes.PROJECT_DETAIL_PATTERN,
                            arguments = listOf(navArgument("projectId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val projectId = backStackEntry.arguments?.getInt("projectId") ?: -1
                            ProjectDetailScreen(
                                projectId = projectId,
                                viewModel = viewModel,
                                onBackClick = { navController.popBackStack() },
                                onCutClick = {
                                    navController.navigate(Routes.cutting(projectId))
                                }
                            )
                        }

                        // Cutting Studio Screen (Manual/Interval/Partitions/AI Tabs)
                        composable(
                            route = Routes.CUTTING_PATTERN,
                            arguments = listOf(navArgument("projectId") { type = NavType.IntType })
                        ) { backStackEntry ->
                            val projectId = backStackEntry.arguments?.getInt("projectId") ?: -1
                            CuttingScreen(
                                projectId = projectId,
                                viewModel = viewModel,
                                onBackClick = { navController.popBackStack() },
                                onExportStarted = {
                                    navController.popBackStack()
                                }
                            )
                        }

                        // Settings and Storage Screen
                        composable(Routes.SETTINGS) {
                            SettingsScreen(
                                viewModel = viewModel,
                                onBackClick = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
