package com.example.util

import android.content.Context
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class SuggestedMoment(
    val name: String,
    val startMs: Long,
    val endMs: Long,
    val reasoning: String
)

object GroqClient {
    private const val TAG = "GroqClient"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Calls Groq Whisper API to transcribe the extracted audio file.
     */
    suspend fun transcribeAudio(audioFile: File, apiKey: String): String {
        if (apiKey.isBlank()) {
            throw IllegalArgumentException("Groq API key is blank. Please enter a valid key in settings.")
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("model", "whisper-large-v3-turbo")
            .addFormDataPart("response_format", "json")
            .addFormDataPart(
                "file",
                audioFile.name,
                audioFile.asRequestBody("audio/m4a".toMediaType())
            )
            .build()

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/audio/transcriptions")
            .addHeader("Authorization", "Bearer $apiKey")
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                Log.e(TAG, "Whisper transcription failed: ${response.code} $bodyStr")
                throw Exception("Whisper failed: Code ${response.code}. $bodyStr")
            }
            val json = JSONObject(bodyStr)
            return json.optString("text", "")
        }
    }

    /**
     * Calls Groq Chat Completions API with a customized prompt to analyze
     * transcriptions and suggest best dramatic/action moments.
     */
    suspend fun suggestMoments(
        transcript: String,
        videoDurationMs: Long,
        apiKey: String
    ): List<SuggestedMoment> {
        if (apiKey.isBlank()) {
            throw IllegalArgumentException("Groq API key is blank. Please configure it in settings.")
        }

        // Random temperature and seed to satisfy the randomness requirement
        val randomTemp = 0.5 + Random.nextDouble(0.4) // ranges 0.5 to 0.9
        
        val systemPrompt = """
            You are an expert cinematic video editor and AI director. 
            Analyze transcripts of long-form videos to discover the absolute best moments (suspenseful, emotional, high-energy, climax, or intriguing dialogues) to crop into small standalone clips (each between 15 seconds and 2 minutes long).
            You MUST return a JSON object with a single "moments" list. Each moment must have "startMs", "endMs", "name", and "reasoning".
            Do not include any explanation outside of the JSON block.
        """.trimIndent()

        val userPrompt = """
            Analyze this transcript:
            \"$transcript\"
            
            Video total duration: $videoDurationMs ms.
            Suggest 3 to 5 highly engaging moments based on the text. Ensure startMs and endMs are well within the video duration (0 to $videoDurationMs).
            Each suggested moment should typically be between 15,000ms and 60,000ms in length.
            Ensure no overlapping clips if possible.
            
            Response format must be strict JSON matching this structure:
            {
              "moments": [
                {
                  "startMs": 10000,
                  "endMs": 40000,
                  "name": "Intense Confrontation",
                  "reasoning": "The character's speech peaks here with critical plot revelations."
                }
              ]
            }
        """.trimIndent()

        val requestJson = JSONObject().apply {
            put("model", "llama-3.3-70b-versatile")
            put("temperature", randomTemp)
            put("response_format", JSONObject().put("type", "json_object"))
            put("messages", okhttp3.internal.immutableListOf(
                JSONObject().put("role", "system").put("content", systemPrompt),
                JSONObject().put("role", "user").put("content", userPrompt)
            ))
        }

        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                Log.e(TAG, "Chat completions failed: ${response.code} $bodyStr")
                throw Exception("Chat completions failed: Code ${response.code}. $bodyStr")
            }
            
            val responseJson = JSONObject(bodyStr)
            val choices = responseJson.getJSONArray("choices")
            if (choices.length() == 0) throw Exception("Empty AI choices returned.")
            
            val content = choices.getJSONObject(0).getJSONObject("message").getString("content")
            return parseMomentsJson(content)
        }
    }

    private fun parseMomentsJson(jsonStr: String): List<SuggestedMoment> {
        val list = ArrayList<SuggestedMoment>()
        val parentObj = JSONObject(jsonStr)
        val momentsArray = parentObj.getJSONArray("moments")
        for (i in 0 until momentsArray.length()) {
            val obj = momentsArray.getJSONObject(i)
            list.add(
                SuggestedMoment(
                    name = obj.getString("name"),
                    startMs = obj.getLong("startMs"),
                    endMs = obj.getLong("endMs"),
                    reasoning = obj.getString("reasoning")
                )
            )
        }
        return list
    }

    /**
     * Generates simulated fallback moments using thematic video guidelines.
     */
    fun generateFallbackMoments(videoDurationMs: Long): List<SuggestedMoment> {
        val duration = if (videoDurationMs <= 0) 300_000L else videoDurationMs
        val count = 3 + Random.nextInt(3) // 3 to 5 moments
        val step = duration / count
        val titles = listOf(
            "Captivating Hook", "Dramatic Reveal", "Climax Spark", 
            "Action Beat", "Key Dialogue Dialogue", "Emotional Shift"
        ).shuffled()
        val reasonings = listOf(
            "High vocal excitement and pacing change detected in the audio channel.",
            "Sudden visual shift or music climax indicates a crucial story development point.",
            "Dialogue density highlights this segment as high significance to the plot.",
            "Strong character interactions and fast cuts make this moment perfect for short video share."
        )

        val list = ArrayList<SuggestedMoment>()
        for (i in 0 until count) {
            val approxStart = i * step + (step * 0.1).toLong()
            val approxEnd = approxStart + (20_000L + Random.nextInt(40_000).toLong()).coerceAtMost(step - 5000)
            
            if (approxEnd <= duration) {
                list.add(
                    SuggestedMoment(
                        name = titles[i % titles.size] + " #${i + 1}",
                        startMs = approxStart,
                        endMs = approxEnd,
                        reasoning = reasonings[i % reasonings.size]
                    )
                )
            }
        }
        return list
    }
}
