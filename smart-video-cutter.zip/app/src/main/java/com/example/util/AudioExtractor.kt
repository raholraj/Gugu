package com.example.util

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

object AudioExtractor {
    private const val TAG = "AudioExtractor"

    /**
     * Extracts the audio track of a video file and saves it as an M4A file.
     * Returns the generated audio file on success, or null on failure.
     */
    fun extractAudio(inputFile: File, outputFile: File): File? {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(inputFile.absolutePath)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read input video file", e)
            return null
        }

        var audioTrackIndex = -1
        var format: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                format = f
                break
            }
        }

        if (audioTrackIndex == -1 || format == null) {
            Log.e(TAG, "No audio track found in the input video file")
            extractor.release()
            return null
        }

        extractor.selectTrack(audioTrackIndex)

        val muxer = try {
            MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create MediaMuxer", e)
            extractor.release()
            return null
        }

        val dstTrackIndex = muxer.addTrack(format)
        muxer.start()

        val bufferSize = 1024 * 512
        val dstBuf = ByteBuffer.allocate(bufferSize)
        val bufferInfo = MediaCodec.BufferInfo()

        while (true) {
            bufferInfo.offset = 0
            bufferInfo.size = extractor.readSampleData(dstBuf, 0)
            if (bufferInfo.size < 0) {
                break
            }
            bufferInfo.presentationTimeUs = extractor.sampleTime
            bufferInfo.flags = extractor.sampleFlags
            muxer.writeSampleData(dstTrackIndex, dstBuf, bufferInfo)
            extractor.advance()
        }

        try {
            muxer.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Muxer stop failed", e)
        } finally {
            muxer.release()
            extractor.release()
        }

        return outputFile
    }
}
