package com.example.util

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

object VideoCutter {
    private const val TAG = "VideoCutter"

    /**
     * Lossless stream copy of a video segment between startMs and endMs.
     * Returns the size of the generated file in bytes.
     */
    fun cutVideo(inputFile: File, outputFile: File, startMs: Long, endMs: Long): Long {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(inputFile.absolutePath)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set data source to extractor", e)
            throw e
        }
        
        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        
        val trackCount = extractor.trackCount
        val trackIndices = HashMap<Int, Int>()
        
        for (i in 0 until trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i)
                val dstTrackIndex = muxer.addTrack(format)
                trackIndices[i] = dstTrackIndex
            }
        }
        
        if (trackIndices.isEmpty()) {
            extractor.release()
            throw IllegalArgumentException("No valid video or audio tracks found in source file.")
        }
        
        muxer.start()
        
        // 1MB buffer
        val bufferSize = 1024 * 1024
        val dstBuf = ByteBuffer.allocate(bufferSize)
        val bufferInfo = MediaCodec.BufferInfo()
        
        // Seek to the start position in microseconds (Us)
        extractor.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        
        while (true) {
            bufferInfo.offset = 0
            bufferInfo.size = extractor.readSampleData(dstBuf, 0)
            if (bufferInfo.size < 0) {
                break
            }
            
            bufferInfo.presentationTimeUs = extractor.sampleTime
            // If sample time exceeds end time, stop reading
            if (bufferInfo.presentationTimeUs > endMs * 1000L) {
                break
            }
            
            bufferInfo.flags = extractor.sampleFlags
            val srcTrackIndex = extractor.sampleTrackIndex
            val dstTrackIndex = trackIndices[srcTrackIndex]
            
            if (dstTrackIndex != null) {
                muxer.writeSampleData(dstTrackIndex, dstBuf, bufferInfo)
            }
            extractor.advance()
        }
        
        try {
            muxer.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Muxer stop failed, continuing...", e)
        } finally {
            muxer.release()
            extractor.release()
        }
        
        return outputFile.length()
    }
}
