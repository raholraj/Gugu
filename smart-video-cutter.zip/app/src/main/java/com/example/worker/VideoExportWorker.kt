package com.example.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.data.database.Clip
import com.example.data.database.VideoCutterDatabase
import com.example.data.repository.ProjectRepository
import com.example.util.VideoCutter
import java.io.File

class VideoExportWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val projectId = inputData.getInt("projectId", -1)
        val videoPath = inputData.getString("videoPath") ?: return Result.failure()
        val startMsArray = inputData.getLongArray("startMsArray") ?: return Result.failure()
        val endMsArray = inputData.getLongArray("endMsArray") ?: return Result.failure()
        val namesArray = inputData.getStringArray("namesArray") ?: return Result.failure()
        val reasoningsArray = inputData.getStringArray("reasoningsArray")

        if (projectId == -1 || startMsArray.isEmpty() || endMsArray.size != startMsArray.size) {
            return Result.failure()
        }

        val db = VideoCutterDatabase.getDatabase(applicationContext)
        val repository = ProjectRepository(db.videoCutterDao())
        
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "video_export_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Video Clip Export", NotificationManager.IMPORTANCE_LOW)
            notificationManager.createNotificationChannel(channel)
        }

        val totalClips = startMsArray.size
        
        // Ensure clips directory exists
        val clipsDir = File(applicationContext.filesDir, "project_${projectId}_clips")
        if (!clipsDir.exists()) {
            clipsDir.mkdirs()
        }

        var successCount = 0
        for (i in 0 until totalClips) {
            val startMs = startMsArray[i]
            val endMs = endMsArray[i]
            val name = namesArray[i]
            val reasoning = reasoningsArray?.getOrNull(i)

            // Update Notification with progress bar
            val notification = NotificationCompat.Builder(applicationContext, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Exporting Video Clips")
                .setContentText("Processing clip ${i + 1} of $totalClips: $name")
                .setProgress(totalClips, i, false)
                .setOngoing(true)
                .build()
            
            notificationManager.notify(NOTIFICATION_ID, notification)

            val outputFile = File(clipsDir, "clip_${System.currentTimeMillis()}_${i}.mp4")
            try {
                val sizeBytes = VideoCutter.cutVideo(File(videoPath), outputFile, startMs, endMs)
                
                // Save database record
                val clip = Clip(
                    projectId = projectId,
                    name = name,
                    videoPath = outputFile.absolutePath,
                    startMs = startMs,
                    endMs = endMs,
                    durationMs = endMs - startMs,
                    fileSize = sizeBytes,
                    aiReasoning = reasoning
                )
                repository.insertClip(clip)
                successCount++
            } catch (e: Exception) {
                e.printStackTrace()
            }
            
            // Post progress update
            setProgress(workDataOf("progress" to ((i + 1) * 100 / totalClips)))
        }

        notificationManager.cancel(NOTIFICATION_ID)

        val finalNotification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Export Complete")
            .setContentText("Successfully exported $successCount of $totalClips video clips!")
            .setAutoCancel(true)
            .build()
        notificationManager.notify(NOTIFICATION_ID + 1, finalNotification)

        return if (successCount > 0) {
            Result.success(workDataOf("successCount" to successCount))
        } else {
            Result.failure()
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}
