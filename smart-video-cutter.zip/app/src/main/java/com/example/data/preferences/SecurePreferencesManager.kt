package com.example.data.preferences

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

object SecurePreferencesManager {
    private const val PREFS_NAME = "secure_video_cutter_prefs"
    private const val KEY_GROQ_API_KEY = "groq_api_key"
    
    // User-supplied default key
    private const val DEFAULT_GROQ_KEY = "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"

    fun getGroqApiKey(context: Context): String {
        val stored = try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            val sharedPreferences = EncryptedSharedPreferences.create(
                PREFS_NAME,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            sharedPreferences.getString(KEY_GROQ_API_KEY, "") ?: ""
        } catch (e: Exception) {
            val sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            sharedPreferences.getString(KEY_GROQ_API_KEY, "") ?: ""
        }

        // If nothing is stored, pre-populate with the provided key so it works out-of-the-box!
        return if (stored.isEmpty()) {
            saveGroqApiKey(context, DEFAULT_GROQ_KEY)
            DEFAULT_GROQ_KEY
        } else {
            stored
        }
    }

    fun saveGroqApiKey(context: Context, apiKey: String) {
        try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            val sharedPreferences = EncryptedSharedPreferences.create(
                PREFS_NAME,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            sharedPreferences.edit().putString(KEY_GROQ_API_KEY, apiKey).apply()
        } catch (e: Exception) {
            val sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            sharedPreferences.edit().putString(KEY_GROQ_API_KEY, apiKey).apply()
        }
    }
}
