package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val videoPath: String,
    val videoUriString: String,
    val thumbnailPath: String?,
    val createdDate: Long = System.currentTimeMillis(),
    val lastModifiedDate: Long = System.currentTimeMillis(),
    val totalStorageUsed: Long = 0L,
    val isPinned: Boolean = false
)

@Entity(
    tableName = "clips",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class Clip(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val projectId: Int,
    val name: String,
    val videoPath: String,
    val startMs: Long,
    val endMs: Long,
    val durationMs: Long,
    val fileSize: Long,
    val createdDate: Long = System.currentTimeMillis(),
    val aiReasoning: String? = null
)
