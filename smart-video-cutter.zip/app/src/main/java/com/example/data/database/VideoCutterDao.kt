package com.example.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoCutterDao {
    // Projects Queries
    @Query("SELECT * FROM projects ORDER BY isPinned DESC, lastModifiedDate DESC")
    fun getAllProjects(): Flow<List<Project>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun getProjectById(id: Int): Flow<Project?>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProjectByIdSync(id: Int): Project?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project): Long

    @Update
    suspend fun updateProject(project: Project)

    @Delete
    suspend fun deleteProject(project: Project)

    // Clips Queries
    @Query("SELECT * FROM clips WHERE projectId = :projectId ORDER BY createdDate DESC")
    fun getClipsForProject(projectId: Int): Flow<List<Clip>>

    @Query("SELECT * FROM clips WHERE projectId = :projectId")
    suspend fun getClipsForProjectSync(projectId: Int): List<Clip>

    @Query("SELECT * FROM clips WHERE id = :id")
    suspend fun getClipById(id: Int): Clip?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: Clip): Long

    @Delete
    suspend fun deleteClip(clip: Clip)

    @Query("DELETE FROM clips WHERE id IN (:ids)")
    suspend fun deleteClipsByIds(ids: List<Int>)

    @Query("SELECT * FROM clips")
    fun getAllClips(): Flow<List<Clip>>
}
