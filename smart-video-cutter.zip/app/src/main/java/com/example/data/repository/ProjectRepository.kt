package com.example.data.repository

import com.example.data.database.Clip
import com.example.data.database.Project
import com.example.data.database.VideoCutterDao
import kotlinx.coroutines.flow.Flow
import java.io.File

class ProjectRepository(private val dao: VideoCutterDao) {

    val allProjects: Flow<List<Project>> = dao.getAllProjects()
    val allClips: Flow<List<Clip>> = dao.getAllClips()

    fun getProject(id: Int): Flow<Project?> = dao.getProjectById(id)

    suspend fun insertProject(project: Project): Long = dao.insertProject(project)

    suspend fun updateProject(project: Project) = dao.updateProject(project)

    suspend fun deleteProject(project: Project) {
        // Delete all clip files from disk first
        val clips = dao.getClipsForProjectSync(project.id)
        clips.forEach { clip ->
            try {
                val file = File(clip.videoPath)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // Delete project from database (cascades to clips table)
        dao.deleteProject(project)
    }

    fun getClipsForProject(projectId: Int): Flow<List<Clip>> = dao.getClipsForProject(projectId)

    suspend fun insertClip(clip: Clip): Long {
        val clipId = dao.insertClip(clip)
        updateProjectStorage(clip.projectId)
        return clipId
    }

    suspend fun deleteClip(clip: Clip) {
        // Delete file from disk
        try {
            val file = File(clip.videoPath)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        dao.deleteClip(clip)
        updateProjectStorage(clip.projectId)
    }

    suspend fun deleteClips(projectId: Int, clipsToDelete: List<Clip>) {
        clipsToDelete.forEach { clip ->
            try {
                val file = File(clip.videoPath)
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        dao.deleteClipsByIds(clipsToDelete.map { it.id })
        updateProjectStorage(projectId)
    }

    private suspend fun updateProjectStorage(projectId: Int) {
        val project = dao.getProjectByIdSync(projectId) ?: return
        val clips = dao.getClipsForProjectSync(projectId)
        val totalSize = clips.sumOf { it.fileSize }
        val updatedProject = project.copy(
            totalStorageUsed = totalSize,
            lastModifiedDate = System.currentTimeMillis()
        )
        dao.updateProject(updatedProject)
    }
}
