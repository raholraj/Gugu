package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Project::class, Clip::class], version = 1, exportSchema = false)
abstract class VideoCutterDatabase : RoomDatabase() {
    abstract fun videoCutterDao(): VideoCutterDao

    companion object {
        @Volatile
        private var INSTANCE: VideoCutterDatabase? = null

        fun getDatabase(context: Context): VideoCutterDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VideoCutterDatabase::class.java,
                    "video_cutter_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
